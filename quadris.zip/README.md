# quadris

It's like Tetris, but we were forced to do it.

## Building

First, you will need:

* `g++` 5.4.0
* `make` (GNU)
* `cmake` >= 2.8.11
* `X11`

1. Execute `make` in the root directory.
2. Execure `./quadris` to run the program.

## Writeups

* [Week 1](https://docs.google.com/document/d/1END41wvpYDNyqouGgvZ6-oucX8QvtHZ1Gi8dri84Vao/edit?usp=sharing)