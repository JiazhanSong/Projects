#include "Level.h"

namespace qd {
  Level::Level(Board& b) : _board{b} { }
}
