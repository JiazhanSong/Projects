#ifndef QDX11_H_
#define QDX11_H_

// Note for some reason, this doesn't work with GCC
// #pragma GCC diagnostic push
// #pragma GCC diagnostic ignored "-Wvariadic-macros"

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>

// #pragma GCC diagnostic pop

#endif // QDX11_H_