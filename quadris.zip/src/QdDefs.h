#ifndef QDDEFS_H_
#define QDDEFS_H_

#define QD_UNREACHABLE(...) __builtin_unreachable();

#endif